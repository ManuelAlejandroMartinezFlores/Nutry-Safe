public class Interfaz {
    
}
