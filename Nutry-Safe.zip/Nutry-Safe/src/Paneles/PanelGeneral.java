package Paneles;
public class PanelGeneral {
    
}
