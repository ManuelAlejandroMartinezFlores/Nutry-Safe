package Paneles;
public class PanelReceta {
    
}
