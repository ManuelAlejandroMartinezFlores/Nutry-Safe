package Paneles;

public class PanelCalorias {
    
}
